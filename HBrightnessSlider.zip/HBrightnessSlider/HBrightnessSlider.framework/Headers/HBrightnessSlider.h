//
//  HBrightnessSlider.h
//  HBrightnessSlider
//
//  Created by Himal Madhushan on 6/24/19.
//  Copyright © 2019 Himal Madhushan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HBrightnessSlider.
FOUNDATION_EXPORT double HBrightnessSliderVersionNumber;

//! Project version string for HBrightnessSlider.
FOUNDATION_EXPORT const unsigned char HBrightnessSliderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HBrightnessSlider/PublicHeader.h>


